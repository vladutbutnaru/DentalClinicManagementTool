package laborator.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.zip.GZIPOutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Exercise6Servlet
 */
@WebServlet("/Exercise6Servlet")
public class Exercise6Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Exercise6Servlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out;
		if (request.getParameter("parameter").equals("true") && isGzipSupported(request) && !isGzipDisabled(request)) {
			out = getGzipWriter(response);
			response.setHeader("Content-Encoding", "gzip");

		} else {
			out = response.getWriter();

		}

		for (int i = 0; i < 100; i++)
			out.append("TEXT LUNG");

	}

	public static PrintWriter getGzipWriter(HttpServletResponse response) throws IOException {
		return (new PrintWriter(new GZIPOutputStream(response.getOutputStream())));
	}

	/** Does the client support gzip? */
	public static boolean isGzipSupported(HttpServletRequest request) {
		String encodings = request.getHeader("Accept-Encoding");
		return ((encodings != null) && (encodings.contains("gzip")));
	}

	/** Has user disabled gzip (e.g., for benchmarking)? */
	public static boolean isGzipDisabled(HttpServletRequest request) {
		String flag = request.getParameter("disableGzip");
		return ((flag != null) && (!flag.equalsIgnoreCase("false")));
	}

}
